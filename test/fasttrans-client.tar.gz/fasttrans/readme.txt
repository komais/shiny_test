1、请上传安装包fasttrans-client.tar.gz到linux服务器
2、解压安装包：tar -zxf fasttrans-client.tar.gz
3、复制快传命令在linux服务器执行（注：fasttrans目录内执行需要在命令前增加“./”，如./rayfile-c）
4、如果想在任意目录执行rayfile-c，需要root权限用户执行install_rayfile.sh

