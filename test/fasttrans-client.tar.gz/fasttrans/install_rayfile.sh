#!/bin/bash

if ! type rayfile-c >/dev/null 2>&1; then
  raytar="rayfile-c"
  folder="/usr/local/rayfile"
  if [ ! -d ${folder} ]; then
    mkdir ${folder}
  fi
  cp -f ${raytar} ${folder} > /dev/null 2>&1
  cp -f ${raytar} /usr/local/bin > /dev/null 2>&1
  echo "Rayfile client installed successfully!"
else
  echo "Rayfile client already installed! You can try 'rayfile-c'"
fi
